# Mój Polski Alfabet – Android

Projekt Android Studio (Kotlin + Jetpack Compose), min. Android 6.0 (API 23).

## Funkcje
- 32 litery polskiego alfabetu, wielkie i małe.
- Pole do rysowania palcem.
- Odczyt polecenia przez Android TextToSpeech (polski głos, jeśli jest dostępny w urządzeniu).
- Wzór litery, cofanie ostatniego pociągnięcia, czyszczenie, punkty i następna litera.

## Ważne ograniczenie sprawdzania
Ta wersja ma prostą kontrolę, czy dziecko wykonało czytelny ruch na polu. Nie jest to pełne rozpoznawanie pisma i nie potwierdza, że narysowany znak rzeczywiście odpowiada zadanej literze. Pełne rozpoznawanie wymagałoby dodania modelu OCR/rozpoznawania pisma obsługującego język polski i przetestowania go na dziecięcym piśmie.

## Budowanie APK
1. Otwórz folder projektu w Android Studio na komputerze.
2. Poczekaj na Gradle Sync.
3. Wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.

Projekt wymaga Android SDK i Gradle do zbudowania APK.
