package pl.edukacja.alfabet

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

private val alphabet = listOf("A","Ą","B","C","Ć","D","E","Ę","F","G","H","I","J","K","L","Ł","M","N","Ń","O","Ó","P","R","S","Ś","T","U","W","Y","Z","Ź","Ż")

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("pl", "PL"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
            }
        }
        setContent { MaterialTheme { AlphabetApp(speak = { speak(it) }) } }
    }
    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alphabet_prompt")
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun AlphabetApp(speak: (String) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var uppercase by remember { mutableStateOf(true) }
    var strokes by remember { mutableStateOf(listOf<List<Offset>>()) }
    var activeStroke by remember { mutableStateOf(listOf<Offset>()) }
    var message by remember { mutableStateOf("Naciśnij głośnik i napisz usłyszaną literę.") }
    var points by remember { mutableIntStateOf(0) }
    var checked by remember { mutableStateOf(false) }
    var showHint by remember { mutableStateOf(true) }
    val currentLetter = if (uppercase) alphabet[index] else alphabet[index].lowercase(Locale("pl", "PL"))
    val prompt = "Napisz literę $currentLetter"

    fun clearBoard() {
        strokes = emptyList()
        activeStroke = emptyList()
        checked = false
    }
    fun nextLetter() {
        index = (index + Random.nextInt(1, alphabet.size)).mod(alphabet.size)
        uppercase = Random.nextBoolean()
        clearBoard()
        message = "Nowa litera! Posłuchaj uważnie."
        speak("Napisz literę ${if (uppercase) alphabet[index] else alphabet[index].lowercase(Locale("pl", "PL"))}")
    }
    fun checkWriting() {
        val all = strokes + listOf(activeStroke).filter { it.isNotEmpty() }
        val result = HandwritingHeuristic.evaluate(all, currentLetter)
        checked = true
        when (result) {
            CheckResult.EMPTY -> message = "Nie widzę jeszcze rysunku. Spróbuj napisać literę palcem."
            CheckResult.POSSIBLE -> {
                points += 1
                message = "Brawo! ⭐ Wygląda na dobrą próbę. Obejrzyj wzór i ćwicz dalej!"
            }
            CheckResult.TRY_AGAIN -> message = "Dobra próba! Porównaj ze wzorem i spróbuj jeszcze raz."
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color(0xFFFFF7E8)).padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("🌈 MÓJ POLSKI ALFABET", fontSize = 23.sp, color = Color(0xFF34558B))
        Text("Posłuchaj, zobacz wzór i napisz palcem", fontSize = 14.sp, color = Color(0xFF444444))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)), shape = RoundedCornerShape(22.dp)) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Twoja litera", color = Color(0xFF34558B))
                    Text("🔊", fontSize = 30.sp)
                }
                Button(onClick = { speak(prompt) }) { Text("POSŁUCHAJ") }
                TextButton(onClick = { showHint = !showHint }) { Text(if (showHint) "Ukryj wzór" else "Pokaż wzór") }
            }
        }
        if (showHint) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Wzór:", fontSize = 16.sp, color = Color(0xFF34558B))
                Text(currentLetter, fontSize = 42.sp, color = Color(0xFFB9C6D8))
                Text("← tak wygląda litera", fontSize = 13.sp, color = Color.Gray)
            }
        }
        Text("Napisz tutaj", fontSize = 17.sp, color = Color(0xFF34558B))
        Canvas(
            modifier = Modifier.fillMaxWidth().weight(1f).background(Color.White, RoundedCornerShape(20.dp))
                .pointerInput(currentLetter) {
                    detectDragGestures(
                        onDragStart = { activeStroke = listOf(it); checked = false },
                        onDrag = { change, _ -> activeStroke = activeStroke + change.position; change.consume() },
                        onDragEnd = {
                            if (activeStroke.isNotEmpty()) strokes = strokes + listOf(activeStroke)
                            activeStroke = emptyList()
                        }
                    )
                }
        ) {
            drawLine(Color(0xFFE8EDF4), Offset(0f, size.height * .25f), Offset(size.width, size.height * .25f), 2f)
            drawLine(Color(0xFFE8EDF4), Offset(0f, size.height * .75f), Offset(size.width, size.height * .75f), 2f)
            (strokes + listOf(activeStroke)).forEach { pts ->
                if (pts.size > 1) {
                    val path = Path().apply {
                        moveTo(pts.first().x, pts.first().y)
                        pts.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    drawPath(path, Color(0xFF2457A6), style = Stroke(width = 13f, cap = androidx.compose.ui.graphics.StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                }
            }
        }
        Text(message, fontSize = 15.sp, color = Color(0xFF34558B))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                if (strokes.isNotEmpty()) strokes = strokes.dropLast(1)
                checked = false
                message = "Możesz poprawić ostatni fragment."
            }) { Text("COFNIJ") }
            OutlinedButton(onClick = { clearBoard(); message = "Pole wyczyszczone. Spróbuj ponownie!" }) { Text("WYCZYŚĆ") }
        }
        Button(
            onClick = { checkWriting() },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF36A66A))
        ) { Text("SPRAWDŹ MOJĄ LITERĘ ⭐", fontSize = 16.sp) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("⭐ Punkty: $points", fontSize = 16.sp)
            TextButton(onClick = { nextLetter() }) { Text("NASTĘPNA ➜") }
        }
        Text("Polski alfabet • 32 litery • małe i wielkie", fontSize = 11.sp, color = Color.Gray)
    }
}

private enum class CheckResult { EMPTY, POSSIBLE, TRY_AGAIN }

/**
 * A simple offline drawing-presence heuristic, not true handwriting OCR.
 * It confirms that the child drew something and gives encouraging feedback.
 * It deliberately avoids claiming that arbitrary handwriting has been recognized correctly.
 */
private object HandwritingHeuristic {
    fun evaluate(strokes: List<List<Offset>>, expected: String): CheckResult {
        val points = strokes.flatten()
        if (points.size < 5) return CheckResult.EMPTY
        val xs = points.map { it.x }
        val ys = points.map { it.y }
        val width = (xs.maxOrNull()!! - xs.minOrNull()!!).coerceAtLeast(1f)
        val height = (ys.maxOrNull()!! - ys.minOrNull()!!).coerceAtLeast(1f)
        val pathLength = strokes.sumOf { stroke ->
            stroke.zipWithNext().sumOf { (a, b) -> hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble()) }
        }
        if (width < 12f || height < 12f || pathLength < 35.0) return CheckResult.TRY_AGAIN
        return CheckResult.POSSIBLE
    }
}
